﻿namespace Test1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Crear una matriz de tamaño NxM
            //Llenarla de valores aleatorios (positivos y negativos)
            //Recorrerla 1 por 1, verificando si cada elemento es negativo
            //Negativo? Cambiar signo
            //Proceder


            //Define rows and columns variables
            int n = 0;
            int m = 0;

            //Define number of rows and columns
            Console.WriteLine("Ingrese el numero de filas");
            n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ingrese el numero de columnas");
            m = Convert.ToInt32(Console.ReadLine());

            //Create matrix
            int[,] Matrix = new int[n, m];
            Random randNum = new Random();

            //Initialize matrix
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    Matrix[i, j] = randNum.Next(-1000, 1000);
                }

            }

            //Display the matrix
            Console.WriteLine("La matriz creada es: ");

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    Console.Write(Matrix[i, j] + "\t");
                }
                Console.WriteLine();
            }

            //Traverse the matrix and make the number positive if negative
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    if (Matrix[i, j] < 0)
                    {
                        Matrix[i, j] = -Matrix[i, j]; 
                    }
                }
            }

            Console.WriteLine("Matriz Modificada: ");
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    Console.Write(Matrix[i, j] + "\t");
                }
                Console.WriteLine();
            }

        }
    }
}